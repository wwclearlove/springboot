<template>
  <!-- 公共底 -->
  <footer id="footer">
    <section class="container">
      <div class>
        <h4 class="hLh30">
          <span class="fsize18 f-fM c-999">友情链接</span>
        </h4>
        <ul class="of flink-list">
          <li>
            <a href="https://www.glasssix.com/" title="第六镜" target="_blank">第六镜</a>
          </li>
        </ul>
        <div class="clear"/>
      </div>
      <div class="b-foot">
        <section class="fl col-7">
          <section class="mr20">
            <section class="b-f-link">
              <a href="#" title="关于我们" target="_blank">关于我们</a>|
              <a href="#" title="联系我们" target="_blank">联系我们</a>|
              <a href="#" title="帮助中心" target="_blank">帮助中心</a>|
              <a href="#" title="资源下载" target="_blank">资源下载</a>|
              <span>)</span>
              <span></span>
            </section>
            <section class="b-f-link mt10">
              <span>西安第六镜科技有限公司 陕ICP备17011468号</span>
            </section>
          </section>
        </section>
        <div class="clear"/>
      </div>
    </section>
  </footer>
</template>